package online.iamtom.stock_ticker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockTickerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockTickerApplication.class, args);
	}

}
